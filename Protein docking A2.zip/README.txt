README

1. The file containing the LJ Parameters, ligand and protein were preprocessed and attached in the sub-folder "Data" 

2. The pre-processing steps can be skipped in R and these data in step 1 imported from local file.

3. The energy, rotation and RMSD functions are then run.

4. The functions can thereafter be called.

5. The proceess takes a while, about 30 mins depending on system specifics.

6. A csv file containing the energy and degree for the best pose is gotten by calling the rotation function. 

7. The  best coordinates for the most favaorable structure is gotten by multiplying the rotation matrix of the
   degree of best pose with the matrix of the ligand coordinates. The file of this best structure is attached